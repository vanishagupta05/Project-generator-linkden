// background.js — service worker

// Listen for messages from popup and content scripts
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "GET_SEARCH_PACK") {
    chrome.storage.local.get(["searchPack"], (res) => {
      sendResponse(res.searchPack || null);
    });
    return true;
  }

  if (msg.type === "SET_SEARCH_PACK") {
    chrome.storage.local.set({ searchPack: msg.data }, () => sendResponse({ ok: true }));
    return true;
  }

  if (msg.type === "GET_CAPTURE_MODE") {
    chrome.storage.local.get(["captureMode", "captureContext"], (res) => {
      sendResponse({ captureMode: res.captureMode || false, captureContext: res.captureContext || null });
    });
    return true;
  }

  if (msg.type === "SET_CAPTURE_MODE") {
    chrome.storage.local.set({ captureMode: msg.active, captureContext: msg.context || null }, () => {
      // Notify all LinkedIn tabs of mode change
      chrome.tabs.query({ url: "https://www.linkedin.com/*" }, (tabs) => {
        tabs.forEach(tab => {
          chrome.tabs.sendMessage(tab.id, { type: "CAPTURE_MODE_CHANGED", active: msg.active, context: msg.context });
        });
      });
      sendResponse({ ok: true });
    });
    return true;
  }

  if (msg.type === "SAVE_PROFILE") {
    chrome.storage.local.get(["savedProfiles"], (res) => {
      const profiles = res.savedProfiles || [];
      const exists = profiles.find(p => p.profileUrl === msg.profile.profileUrl);
      if (!exists) {
        profiles.unshift({ ...msg.profile, savedAt: new Date().toISOString() });
        chrome.storage.local.set({ savedProfiles: profiles }, () => sendResponse({ ok: true, count: profiles.length }));
      } else {
        sendResponse({ ok: false, reason: "already_saved", count: profiles.length });
      }
    });
    return true;
  }

  if (msg.type === "GET_SAVED_PROFILES") {
    chrome.storage.local.get(["savedProfiles"], (res) => {
      sendResponse(res.savedProfiles || []);
    });
    return true;
  }

  if (msg.type === "DELETE_PROFILE") {
    chrome.storage.local.get(["savedProfiles"], (res) => {
      const profiles = (res.savedProfiles || []).filter(p => p.profileUrl !== msg.profileUrl);
      chrome.storage.local.set({ savedProfiles: profiles }, () => sendResponse({ ok: true }));
    });
    return true;
  }

  if (msg.type === "EXPORT_PROFILES") {
    chrome.storage.local.get(["savedProfiles"], (res) => {
      sendResponse(res.savedProfiles || []);
    });
    return true;
  }

  if (msg.type === "CLEAR_ALL") {
    chrome.storage.local.remove(["savedProfiles", "captureMode", "captureContext", "searchPack"], () => {
      sendResponse({ ok: true });
    });
    return true;
  }
});

// Open LinkedIn search URL when triggered from external app
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg.type === "OPEN_LINKEDIN_SEARCH" && msg.searchPack) {
    // Store the search pack
    chrome.storage.local.set({ searchPack: msg.searchPack }, () => {
      chrome.tabs.create({ url: msg.searchPack.url }, () => sendResponse({ ok: true }));
    });
    return true;
  }
});
